# POKEMON GAME

```

## References

-[https://stackoverflow.com/questions/11047756/getting-enum-associated-with-int-value]
-[http://users.encs.concordia.ca/~sthiel/soen387/Thesis_Stuart.pdf]
