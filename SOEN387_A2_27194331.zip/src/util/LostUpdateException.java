package util;

public class LostUpdateException extends Exception{
	
	public LostUpdateException(String m){
		super(m);
	}

}
